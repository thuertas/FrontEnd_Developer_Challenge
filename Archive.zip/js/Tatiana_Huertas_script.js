function showMoreButton() {
    var moreInfo = document.getElementById("hidden-text");
    var button = document.getElementById("show-more");
    if (moreInfo.classList.contains("hide")) {
        moreInfo.classList.toggle("hide");
        button.innerHTML = "Show less";
    } else {
        moreInfo.classList.toggle("hide");
        button.innerHTML = "Show more";
    }
}